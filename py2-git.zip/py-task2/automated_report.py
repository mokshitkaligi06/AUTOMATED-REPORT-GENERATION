import pandas as pd
from fpdf import FPDF

def analyze_data(file_path):
    df = pd.read_csv(file_path)

    # Automatically fill missing values in all numeric columns with their mean
    numeric_cols = df.select_dtypes(include=['number']).columns
    for col in numeric_cols:
        df[col] = df[col].fillna(df[col].mean())

    summary = df.describe(include='all')
    return summary

class PDFReport(FPDF):
    def header(self):
        self.set_font('Arial', 'B', 14)
        self.cell(0, 10, 'Automated Data Analysis Report', 0, 1, 'C')

    def chapter_title(self, title):
        self.set_font('Arial', 'B', 12)
        self.cell(0, 10, title, 0, 1)
        self.ln(4)

    def chapter_body(self, body):
        self.set_font('Arial', '', 11)
        self.multi_cell(0, 10, body)
        self.ln()

def generate_report(summary, output_pdf):
    pdf = PDFReport()
    pdf.add_page()

    pdf.chapter_title("Summary Statistics")
    summary_str = summary.to_string()
    pdf.chapter_body(summary_str)

    pdf.output(output_pdf)
    print(f"Report generated and saved as {output_pdf}")

if __name__ == "__main__":
    input_file = "input_data.csv"  # Your CSV file path here
    output_file = "data_report.pdf"  # Output PDF filename

    summary_stats = analyze_data(input_file)
    generate_report(summary_stats, output_file)
